﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PhotoSessionBooking
{
    public partial class NewBookingForm : Form
    {
        public NewBookingForm()
        {
            InitializeComponent();

        }



        private void btnConfirmBooking_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string sessionType = cmbSessionType.SelectedItem?.ToString();
            // DateTime date = dateTimePickerDate.Value.Date;
            string date = dateTimePickerDate.Value.Date.ToString("yyyy-MM-dd");
            string time = txtTime.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) ||
                string.IsNullOrWhiteSpace(phone) ||
                string.IsNullOrWhiteSpace(sessionType) ||
                string.IsNullOrWhiteSpace(time))
            {
                MessageBox.Show("الرجاء تعبئة جميع الحقول.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                //string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\\Users\\This pc\\source\\repos\\PhotoSessionBooking\\PhotoSessionBooking\\PhotoSessionDB.mdf"";Integrated Security=True";
              //  string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\This pc\\source\\repos\\PhotoSessionBooking\\PhotoSessionBooking\\PhotoSessionDB.mdf\";Integrated Security=True";
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\This pc\source\repos\PhotoSessionBooking\PhotoSessionBooking\PhotoSessionDB.mdf;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO photo (Name, Phone, SessionType, Date, Time) VALUES (@Name, @Phone, @SessionType, @Date, @Time)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.Parameters.AddWithValue("@SessionType", sessionType);
                        cmd.Parameters.AddWithValue("@Date", date);
                        cmd.Parameters.AddWithValue("@Time", time);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("تم تأكيد الحجز بنجاح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtName.Clear();
                txtPhone.Clear();
                txtTime.Clear();
                cmbSessionType.SelectedIndex = -1;
                dateTimePickerDate.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء حفظ البيانات: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
