﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoSessionBooking
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ( textBox1.Text == "photo" && textBox2.Text == "12345")
            {
                
                MainForm main = new MainForm();
                main.Show();
                this.Hide();
            }
            else

            {
                MessageBox.Show("اسم المستخدم او كلمة غير صحيحة");

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           

                
        }
    }
}
