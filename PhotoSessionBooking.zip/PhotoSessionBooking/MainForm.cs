﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhotoSessionBooking;

namespace PhotoSessionBooking
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void btnNewBooking_Click(object sender, EventArgs e)
        {
            // فتح واجهة الحجز
            NewBookingForm bookingForm = new NewBookingForm();
            bookingForm.Show();
        }

        private void btnViewBookings_Click(object sender, EventArgs e)
        {
            // فتح واجهة عرض الحجوزات
            ViewBookingsForm viewForm = new ViewBookingsForm();
            viewForm.Show();
        }
    }
}
