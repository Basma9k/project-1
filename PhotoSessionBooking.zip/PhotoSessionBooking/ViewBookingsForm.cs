﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoSessionBooking
{
    public partial class ViewBookingsForm : Form
    {
        // string connectionString  = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename""=C:\\Users\\This pc\\source\\repos\\PhotoSessionBooking\\PhotoSessionBooking\\PhotoSessionDB.mdf"";Integrated Security=True";
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\This pc\\source\\repos\\PhotoSessionBooking\\PhotoSessionBooking\\PhotoSessionDB.mdf\";Integrated Security=True";
        public ViewBookingsForm()
        {
            InitializeComponent();
            LoadBookings();
        }
       
        
            private void LoadBookings()
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT * FROM photo";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvBookings.DataSource = dt;
                }
            }

            private void btnRefresh_Click(object sender, EventArgs e)
            {
                if (dgvBookings.CurrentRow != null)
                {
                    int id = Convert.ToInt32(dgvBookings .CurrentRow.Cells[0].Value);
                    string name = dgvBookings .CurrentRow.Cells[1].Value.ToString();
                    string phone = dgvBookings .CurrentRow.Cells[2].Value.ToString();
                    string sessionType = dgvBookings .CurrentRow.Cells[3].Value.ToString();
                    string date = dgvBookings .CurrentRow.Cells[4].Value.ToString();
                    string time = dgvBookings .CurrentRow.Cells[5].Value.ToString();

                  using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        string query = "UPDATE photo SET name=@name, phone=@phone, sessionType=@sessionType, date=@date, time=@time WHERE id=@id";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@phone", phone);
                        cmd.Parameters.AddWithValue("@sessionType", sessionType);
                        cmd.Parameters.AddWithValue("@date", date);
                        cmd.Parameters.AddWithValue("@time", time);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("تم تحديث الحجز بنجاح");
                    LoadBookings();
                }
            }

            private void btnDelete_Click(object sender, EventArgs e)
            {
                if (dgvBookings .CurrentRow != null)
                {
                    int id = Convert.ToInt32(dgvBookings .CurrentRow.Cells[0].Value);
                    DialogResult result = MessageBox.Show("هل أنت متأكد من حذف هذا الحجز؟", "تأكيد الحذف", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection con = new SqlConnection(connectionString))
                        {
                            con.Open();
                            string query = "DELETE FROM photo WHERE id=@id";
                            SqlCommand cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@id", id);
                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("تم حذف الحجز بنجاح");
                        LoadBookings();
                    }
                }
            }

            private void btnBack_Click(object sender, EventArgs e)
            {
                this.Hide();
                MainForm main = new MainForm(); // إذا كانت واجهتك الرئيسية اسمها غير MainForm، غيري الاسم هنا
                main.Show();
            }
        }
    }
